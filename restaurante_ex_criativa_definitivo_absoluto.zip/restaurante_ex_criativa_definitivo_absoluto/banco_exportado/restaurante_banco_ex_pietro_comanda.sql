-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: restaurante_banco_ex_pietro
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comanda`
--

DROP TABLE IF EXISTS `comanda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comanda` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo` int NOT NULL,
  `estado` varchar(20) NOT NULL DEFAULT 'aberta',
  `cliente_id` int DEFAULT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  `fechado_em` datetime DEFAULT NULL,
  `pago_em` datetime DEFAULT NULL,
  `criado_por` int DEFAULT NULL,
  `fechado_por` int DEFAULT NULL,
  `pago_por` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `cliente_id` (`cliente_id`),
  KEY `criado_por` (`criado_por`),
  KEY `fechado_por` (`fechado_por`),
  KEY `pago_por` (`pago_por`),
  CONSTRAINT `comanda_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `comanda_ibfk_2` FOREIGN KEY (`criado_por`) REFERENCES `usuario` (`id`),
  CONSTRAINT `comanda_ibfk_3` FOREIGN KEY (`fechado_por`) REFERENCES `usuario` (`id`),
  CONSTRAINT `comanda_ibfk_4` FOREIGN KEY (`pago_por`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comanda`
--

LOCK TABLES `comanda` WRITE;
/*!40000 ALTER TABLE `comanda` DISABLE KEYS */;
INSERT INTO `comanda` VALUES (1,1,'paga',1,'2025-11-25 00:33:21','2025-11-25 00:36:42','2025-11-25 00:39:25',1,2,3),(2,2,'paga',1,'2025-11-25 00:47:06','2025-11-25 00:54:03','2025-11-25 00:55:03',1,2,3),(3,3,'paga',1,'2025-11-25 00:56:39','2025-11-25 01:09:39','2025-11-25 01:43:03',1,2,3),(4,4,'paga',1,'2025-11-25 02:31:01','2025-11-25 02:34:01','2025-11-25 02:36:43',1,2,3),(5,5,'paga',1,'2025-11-25 02:41:43','2025-11-25 02:43:28','2025-11-25 02:50:32',1,2,3),(6,6,'paga',1,'2025-11-25 02:56:57','2025-11-25 02:57:41','2025-11-25 02:59:13',1,2,3);
/*!40000 ALTER TABLE `comanda` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-25  0:57:33
