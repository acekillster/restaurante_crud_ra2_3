SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:root@localhost/restaurante_banco_ex_pietro'
SQLALCHEMY_TRACK_MODIFICATIONS = False
SECRET_KEY = 'restaurante_pietro_senha'
